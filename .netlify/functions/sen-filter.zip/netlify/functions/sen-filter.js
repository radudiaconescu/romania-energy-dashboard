var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var sen_filter_exports = {};
__export(sen_filter_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(sen_filter_exports);
async function handler() {
  const start = Date.now();
  console.log(`[sen-filter] request received at ${(/* @__PURE__ */ new Date()).toISOString()}`);
  try {
    const res = await fetch("https://www.transelectrica.ro/sen-filter", {
      headers: {
        Referer: "https://www.transelectrica.ro/",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
      }
    });
    console.log(`[sen-filter] upstream responded ${res.status} in ${Date.now() - start}ms`);
    if (!res.ok) {
      console.error(`[sen-filter] upstream error: ${res.status} ${res.statusText}`);
      return { statusCode: res.status, body: `Upstream error: ${res.status}` };
    }
    const body = await res.text();
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "public, s-maxage=30, stale-while-revalidate=30",
        "Access-Control-Allow-Origin": "*"
      },
      body
    };
  } catch (err) {
    console.error(`[sen-filter] fetch failed after ${Date.now() - start}ms:`, err.message);
    return { statusCode: 502, body: `Fetch failed: ${err.message}` };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
